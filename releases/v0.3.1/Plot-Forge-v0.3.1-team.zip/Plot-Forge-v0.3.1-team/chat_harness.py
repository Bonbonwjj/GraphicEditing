"""Persistent, chart-scoped draft workflow. No candidate replaces an applied chart."""
import base64
import copy
from functools import lru_cache
import csv
import hashlib
import io
import json
import os
import re
import shutil
from pathlib import Path
import threading
import time
import uuid
import chat_cancellation as cancellation
from datetime import datetime, timezone

from agent_http import post_json
from chat_agent import propose, validate_response, MAX_MODEL_ATTEMPTS, model_attempt_limit


@lru_cache(maxsize=8)
def chat_image_thumbnail(raw):
    """Content-keyed cache: changing any image bytes invalidates the thumbnail."""
    from PIL import Image
    with Image.open(io.BytesIO(raw)) as image:
        preview=image.copy()
        preview.thumbnail((1024,1024),Image.Resampling.LANCZOS)
        encoded=io.BytesIO()
        preview.save(encoded,format='PNG',compress_level=3)
    return encoded.getvalue()
from model_config import effective as effective_model_config

LOCKS = {}
LOCK_GUARD = threading.Lock()


def lock(key):
    with LOCK_GUARD:
        from shared_workspace import shared_lock_path,SharedFileLock
        path=shared_lock_path(key)
        return LOCKS.setdefault(str(key),SharedFileLock(path) if path else threading.RLock())


def uid(prefix):
    return prefix + '_' + str(uuid.uuid4())


def digest(value):
    return 'sha256:' + hashlib.sha256(value if isinstance(value, bytes) else value.encode()).hexdigest()


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8'))


def atomic_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8', newline="\n")
    for attempt in range(6):
        try:
            temporary.replace(path)
            return
        except PermissionError as error:
            # Windows readers/indexers can briefly deny replacement while
            # polling progress. Retry the atomic swap, never truncate the live file.
            if os.name != 'nt' or getattr(error,'winerror',None) not in (5,32,33) or attempt == 5:
                try: temporary.unlink(missing_ok=True)
                except OSError: pass
                raise
            time.sleep(.01 * 2**attempt)


MAX_PROMPT_CSV_CHARS = 40_000


def scoped_plot_data(files, chart):
    """Keep revision hashes for every CSV, but send only chart-relevant rows to the model."""
    all_sources = '\n'.join(item['content'] for item in files.values() if item['path'].endswith('.py'))
    entry = files.get('charts/' + chart + '.py', {}).get('content', '')
    data_names = [Path(path).name for path in files if path.endswith(('.csv', '.tsv'))]
    sources = entry if any(name in entry for name in data_names) else all_sources
    result = []
    # Extracted packages carry their immutable schema and selected figure inputs.
    # Binary values remain local; model context gets names/hashes and bounded JSON.
    manifest_item = files.get('data/plot-data/manifest.json')
    if manifest_item:
        manifest = json.loads(manifest_item['content'])
        figure = next((f for f in manifest.get('figures', []) if f.get('figure_id') == chart), None)
        if figure:
            reference_path = 'data/plot-data/' + manifest.get('validation', {}).get('plot_input_reference', '')
            reference_item = files.get(reference_path)
            inputs = json.loads(reference_item['content']).get('figures', {}).get(chart, {}).get('inputs', []) if reference_item else []
            artifacts = {a['path']: a for a in manifest.get('artifacts', [])}
            for relative in figure.get('artifacts', []):
                artifact = artifacts[relative]
                path = 'data/plot-data/' + relative
                keys = [i.get('key', '') for i in inputs if i.get('artifact') == relative]
                item = files.get(path, {})
                content = item.get('content', '') if artifact['format'] == 'json' else ''
                if relative == manifest.get('validation', {}).get('plot_input_reference'):
                    continue  # Original input capture is validation evidence, not model data.
                result.append({'path':path, 'sha256':item.get('sha256', 'sha256:'+artifact['sha256']),
                               'columns':keys, 'format':artifact['format'], 'read_only':True,
                               'content':content if len(content) <= MAX_PROMPT_CSV_CHARS else '',
                               'content_scope':'complete' if content and len(content) <= MAX_PROMPT_CSV_CHARS else 'schema_only'})
    for item in files.values():
        path = item['path']
        if any(existing['path'] == path for existing in result):
            continue
        if path.endswith('.json') and path.startswith(('data/','lib/universal/source/')):
            try: value=json.loads(item.get('content') or '{}')
            except ValueError: value={}
            columns=list(value) if isinstance(value,dict) else list(value[0]) if isinstance(value,list) and value and isinstance(value[0],dict) else []
            result.append({**item,'format':'json','columns':columns,'content':'','content_scope':'schema_only',
                           'source_row_count':len(value) if isinstance(value,list) else None,'read_only':True})
            continue
        if not path.endswith(('.csv', '.tsv')):
            continue
        delimiter = '\t' if path.endswith('.tsv') else ','
        rows = list(csv.reader(io.StringIO(item['content']), delimiter=delimiter))
        columns, data_rows = (rows[0], rows[1:]) if rows else ([], [])
        referenced = Path(path).name in sources or path in sources
        selected = data_rows if referenced else []
        scope = 'truncated_sample' if item.get('content_scope')=='truncated_sample' and referenced else 'complete' if referenced else 'schema_only'
        id_column = next((i for i, name in enumerate(columns) if name in ('panel_id', 'chart_id')), None)
        if referenced and id_column is not None and chart in sources:
            matching = [row for row in data_rows if len(row) > id_column and row[id_column] == chart]
            if matching:
                selected, scope = matching, 'matching_chart_rows'
        output = io.StringIO()
        writer = csv.writer(output, delimiter=delimiter, lineterminator='\n')
        if columns:
            writer.writerow(columns)
        included = 0
        for row in selected:
            before = output.tell()
            writer.writerow(row)
            if output.tell() > MAX_PROMPT_CSV_CHARS:
                output.seek(before)
                output.truncate()
                scope = 'truncated_sample'
                break
            included += 1
        result.append({**item, 'content': output.getvalue(), 'columns': columns,
                       'read_only': True, 'content_scope': scope,
                       'source_row_count': item.get('source_row_count',len(data_rows)), 'included_row_count': included})
    return result


class ChatHarness:
    def __init__(self, host, agent=None, renderer=None):
        self.host = host
        self.agent = agent or self.call_agent
        self.renderer = renderer

    def call_agent(self, context):
        url = os.environ.get('CHAT_AGENT_URL')
        model_auth=effective_model_config()
        if model_auth.get('provider') == 'chatgpt':
            url = None  # OAuth credentials and selected source stay on the direct official route.
        request=dict(context,_model_auth=model_auth)
        if url:request.pop('_context_progress',None)
        if not url:return propose(request)
        budget=context.get('_model_attempt_budget',{'used':0})
        remaining=model_attempt_limit(budget)-budget['used']
        if remaining<=0:raise ValueError('本张图本轮模型调用已达到 3 次上限')
        try:
            response=post_json(url.rstrip('/')+'/v1/chat-edit', request, timeout=600)
        except Exception:
            # A failed remote Agent may already have spent its available calls.
            budget['used']=MAX_MODEL_ATTEMPTS
            raise
        used=response.get('model_attempts_used')
        reads=response.get('model_context_reads_used',budget.get('context_reads',0))
        from chat_agent import MAX_CONTEXT_READ_ROUNDS
        if type(reads) is int and budget.get('context_reads',0)<=reads<=MAX_CONTEXT_READ_ROUNDS:
            budget['context_reads']=reads
        remaining=model_attempt_limit(budget)-budget['used']
        budget['used']+=used if type(used) is int and 1<=used<=remaining else remaining
        return response

    def directory(self, project):
        return self.host.project_path(project) / '.chat'

    def identity(self, project):
        folder = self.directory(project)
        with lock(folder):
            path = folder/'identity.json'
            value = read_json(path) if path.exists() else {'project_id':uid('prj'), 'charts':{}}
            p = self.host.project_path(project)
            excluded = set(read_json(p/'project.json').get('non_chart_scripts', []))
            for f in sorted((p/'charts').glob('*.py')):
                if f.stem not in excluded:
                    value['charts'].setdefault(f.stem, uid('cht'))
            atomic_json(path,value)
            return value

    def records(self, project, charts):
        p = self.host.project_path(project)
        identity = self.identity(project)
        result = []
        for chart in charts:
            self.host.chart_path(project,chart)
            if chart not in identity['charts']:
                raise ValueError('所选条目不是已登记的图')
            result.append({'chart':chart,'chart_id':identity['charts'][chart],
                           'display_name':self.host.chart_naming(p,chart)['display_name']})
        return result

    def snapshot(self, project, chart):
        p, entry = self.host.chart_path(project, chart)
        candidates = [entry]
        from native_project import selection
        native_id = selection(p, entry.relative_to(p).as_posix())
        from universal_project import selection as universal_selection
        universal_id = universal_selection(p, entry.relative_to(p).as_posix())
        universal_root = None
        if universal_id:
            registry=read_json(p/'universal-project.json')
            universal_root=p/registry['source_root']
            universal_record=registry['figures'][universal_id]
            candidates += [universal_root/path for path in [*universal_record.get('source_files',[]),
                                                             *universal_record.get('input_files',[])]]
        else:
            for directory in ('lib','data'):
                dependency_root = p/directory/'native'/native_id if native_id else p/directory
                if dependency_root.exists():
                    candidates += [f for f in dependency_root.rglob('*') if f.is_file() and '__pycache__' not in f.parts]
        if native_id:
            candidates.append(p/'native-project.json')
        if universal_id:
            candidates.append(p/'universal-project.json')
        # Root-level project helpers are also dependencies.
        candidates += list(p.glob('*.py'))
        if (p/'data_sources.json').is_file(): candidates.append(p/'data_sources.json')
        if (p/'panel-mappings'/f'{chart}.json').is_file(): candidates.append(p/'panel-mappings'/f'{chart}.json')
        files = {}
        binary_dependencies = {}
        total = 0
        for f in sorted(set(candidates)):
            if f.is_symlink() or not f.resolve().is_relative_to(p.resolve()):
                raise ValueError('项目含有指向外部的依赖；请将绘图文件直接放入项目')
            from project_preparation import sha
            if (universal_root or native_id) and f.suffix.lower() in ('.csv','.tsv','.json') and f.stat().st_size>256_000:
                path=f.relative_to(p).as_posix()
                file_hash='sha256:'+sha(f)
                content=''
                if f.suffix.lower() in ('.csv','.tsv'):
                    delimiter='\t' if f.suffix.lower()=='.tsv' else ','
                    sample=io.StringIO()
                    writer=csv.writer(sample,delimiter=delimiter,lineterminator='\n')
                    with f.open(encoding='utf-8-sig',newline='') as stream:
                        reader=csv.reader(stream)
                        for index,row in enumerate(reader):
                            if index>=100 or sample.tell()>MAX_PROMPT_CSV_CHARS:
                                break
                            writer.writerow(row)
                    content=sample.getvalue()
                files[path]={'path':path,'content':content,'sha256':file_hash,'writable':False,
                             'content_scope':'truncated_sample','source_row_count':None}
                continue
            if f.suffix.lower() not in ('.py','.csv','.tsv','.json'):
                if f.suffix.lower() in ('.npz','.npy','.parquet','.feather','.xlsx','.xls','.h5','.hdf5',
                                         '.yaml','.yml','.toml','.ini','.png','.jpg','.jpeg','.webp',
                                         '.svg','.ttf','.otf','.pptx','.md','.txt'):
                    binary_dependencies[f.relative_to(p).as_posix()] = 'sha256:'+sha(f)
                continue
            raw = f.read_bytes(); total += len(raw)
            if total > 8_000_000:
                raise ValueError('绘图上下文超过 8 MB；请将这张图实际使用的汇总数据整理成较小文件')
            path = f.relative_to(p).as_posix()
            files[path] = {'path':path,'content':raw.decode('utf-8-sig').replace('\r\n', '\n').replace('\r', '\n'),'sha256':digest(raw),'writable':f==entry}
        dependencies = dict((k,v['sha256']) for k,v in files.items())
        dependencies.update(binary_dependencies)
        if universal_root:
            for dependency in sorted(path for path in universal_root.rglob('*') if path.is_file() and path not in candidates):
                from project_preparation import sha
                dependencies[dependency.relative_to(p).as_posix()] = 'sha256:'+sha(dependency)
        # The Chat Skill controls future proposals, not the applied chart or
        # an already-rendered draft. Updating its wording must not invalidate
        # a candidate that was reviewed against unchanged drawing inputs.
        dependencies.update(self.platform_dependencies())
        if native_id:
            dependencies['@platform/native_plot_runtime.py'] = digest((self.host.ROOT/'native_plot_runtime.py').read_bytes())
        if universal_id:
            dependencies['@platform/universal_plot_runtime.py'] = digest((self.host.ROOT/'universal_plot_runtime.py').read_bytes())
        from bundle_bindings import signature as bundle_signature
        bundle_revision=bundle_signature(p)
        if bundle_revision: dependencies['@bundle/source']=bundle_revision
        revision = digest(json.dumps(dependencies,sort_keys=True))
        return files, revision

    def platform_dependencies(self):
        return {'@platform/'+str(f.relative_to(self.host.ROOT)):digest(f.read_bytes())
                for f in (self.host.ROOT/'studio_style.py',self.host.NORMALIZATION_PROFILE)}

    def ensure_current_base(self,session,record):
        """Refresh live inputs; retain old candidates with an explicit warning."""
        chart_id=record['chart_id']
        files,current=self.snapshot(session['project'],record['chart'])
        if current!=session['base_revisions'][chart_id]:
            for draft in session.get('drafts',[]):
                if draft['chart_id']==chart_id:
                    draft.setdefault('warnings',[]).append('正式版本或依赖已变化；仍可应用或继续修改此候选，请核对差异。')
            session['base_sources'][chart_id]=files
            session['base_revisions'][chart_id]=current
            session['base_platform_hashes']=self.platform_dependencies()
        return files,current

    def create(self, project, charts, references=None):
        if not isinstance(charts,list) or not charts or len(charts)>100 or len(set(charts))!=len(charts):
            raise ValueError('请选择 1 到 100 张不重复的图')
        records = self.records(project,charts)
        session = {'id':uid('ses'),'project':project,'project_id':self.identity(project)['project_id'],
                   'chart_ids':[r['chart_id'] for r in records], 'charts':records,
                   'base_revisions':{},'base_sources':{},'active_drafts':{},'turns':[], 'drafts':[],
                   'base_platform_hashes':self.platform_dependencies(),
                   'references':self.references(project,references or []),'layout_exceptions':{},'status':'open',
                   'created_at':datetime.now(timezone.utc).isoformat()}
        for record in records:
            files,revision = self.snapshot(project,record['chart'])
            session['base_revisions'][record['chart_id']] = revision
            session['base_sources'][record['chart_id']] = files
            record['_image']=self.cached_image(project,record['chart'],files['charts/'+record['chart']+'.py']['content'],revision)
            if self.snapshot(project,record['chart'])[1]!=revision:raise ValueError('项目在创建会话时发生变化，请重试')
        self.save(session)
        return self.public(session)

    def path(self, project, sid):
        if not isinstance(sid,str) or not sid.startswith('ses_'):
            raise ValueError('Invalid session ID')
        uuid.UUID(sid[4:])
        return self.directory(project)/'sessions'/sid/'session.json'

    def load(self, project, sid):
        path = self.path(project,sid)
        if not path.is_file():
            raise ValueError('改图会话不存在')
        return read_json(path)

    def save(self, session):
        atomic_json(self.path(session['project'],session['id']),session)

    def public(self, session):
        value=json.loads(json.dumps(session))
        value.pop('base_sources',None)
        value.pop('font_context_cache',None)
        for record in value['charts']:record.pop('_image',None)
        for draft in value['drafts']:
            draft['can_continue'] = self.can_continue_draft(draft)
            draft['can_apply'] = self.can_apply_draft(draft)
            draft.pop('_layout_reference',None)
            draft['warnings'] = self.candidate_warnings(draft)
            if draft.get('baseline_image_path'):
                draft['baseline_image_url'] = (f"/api/projects/{session['project']}/chat/sessions/{session['id']}"
                                               f"/drafts/{draft['id']}/baseline-image")
            draft.pop('image_path',None)
            draft.pop('_image',None)
            draft.pop('baseline_image_path',None)
        for turn in value['turns']:
            turn.pop('_diagnostics',None)
            for result in turn.get('results',[]):result.pop('_image',None)
        for ref in value['references']:
            ref.pop('source_files',None);ref.pop('plot_data',None);ref.pop('_image',None)
        return value

    def get(self, project, sid):
        path=self.path(project,sid)
        guard=lock(path)
        acquired=guard.acquire(blocking=False)
        try:
            session=self.load(project,sid)
            if acquired and session.get('status')=='running':
                session['status']='interrupted'
                session.pop('progress',None)
                self.save(session)
            return self.public(session)
        finally:
            if acquired:guard.release()

    def list(self, project, charts=None):
        result=[]
        for path in (self.directory(project)/'sessions').glob('*/session.json'):
            session=self.get(project,path.parent.name)
            if charts is None or set(charts)=={r['chart'] for r in session['charts']}:
                result.append(session)
        return sorted(result,key=lambda s:s['created_at'],reverse=True)

    def manage(self, project, sid, action, body):
        path=self.path(project,sid)
        root=self.directory(project)
        if any(p.is_symlink() for p in (root,root/'sessions',path.parent,path)):
            raise ValueError('会话管理不允许符号链接')
        guard=lock(path)
        if not guard.acquire(blocking=False):
            raise ValueError('会话仍在运行，请先停止并等待结束后再保存或删除')
        try:
            session=self.load(project,sid)
            if action=='save':
                title=body.get('title','')
                if not isinstance(title,str) or len(title.strip())>100:
                    raise ValueError('会话名称须不超过 100 个字符')
                session['title']=title.strip() or session.get('title') or '已保存会话'
                session['saved_at']=time.time()
                self.save(session)
                return self.public(session)
            if action!='delete' or body.get('confirm_session_id')!=sid:
                raise ValueError('请确认删除指定会话')
            folder=path.parent
            if folder.is_symlink() or path.is_symlink() or not folder.resolve().is_relative_to(root.resolve()):
                raise ValueError('不允许删除外部会话目录')
            # Recoverable deletion. Shared reference assets and all applied
            # charts/history live outside this exact session directory.
            trash=root/'deleted_sessions'
            if trash.is_symlink():raise ValueError('会话回收目录不可为符号链接')
            trash.mkdir(exist_ok=True)
            folder.rename(trash/(sid+'_'+uuid.uuid4().hex))
            return {'deleted':True,'recoverable':True,'session_id':sid}
        finally:guard.release()

    def history(self, project):
        """Project-wide chat timeline without candidate source code or CSV snapshots."""
        sessions=[]
        draft_fields=('id','turn_id','chart','chart_id','display_name','status','summary',
                      'reason','warnings','layout','image_url','baseline_image_url',
                      'normalization_report','font_audit','visual_change','created_at')
        for session in self.list(project):
            drafts=[]
            for draft in session['drafts']:
                item={key:draft[key] for key in draft_fields if key in draft}
                proposal=draft.get('proposal') or {}
                item['proposal']={key:proposal[key] for key in
                                  ('interpreted_request','expected_effects','normalization_checks')
                                  if key in proposal}
                drafts.append(item)
            sessions.append({'id':session['id'],'project':project,'charts':session['charts'],
                             'title':session.get('title'),'saved_at':session.get('saved_at'),
                             'status':session['status'],'created_at':session['created_at'],
                             'active_drafts':session['active_drafts'],'turns':session['turns'],
                             'drafts':drafts})
        return sessions

    def cached_image(self,project,chart,source,revision):
        p=self.host.project_path(project)
        with self.host.preview_lock(p,chart):
            image=p/'previews'/(chart+'.png');meta=p/'previews'/(chart+'.json')
            if not image.is_file() or not meta.is_file():return None
            if read_json(meta).get('signature')!=self.host.preview_signature(p,source):return None
            assets=self.directory(project)/'reference_assets';assets.mkdir(parents=True,exist_ok=True)
            payload=image.read_bytes()
            # Both bytes and dependency revision contribute to this immutable asset name.
            target=assets/(digest(revision+digest(payload)).split(':')[1]+'.png')
            if not target.exists():
                with target.open('xb') as stream:stream.write(payload)
            return str(target)

    def references(self, project, names):
        if not isinstance(names,list) or len(names)>10:
            raise ValueError('最多选择 10 张参照图')
        result=[]
        p=self.host.project_path(project)
        for record in self.records(project,list(dict.fromkeys(names))):
            files,revision=self.snapshot(project,record['chart'])
            item={**record,'revision_id':revision,'read_only':True,
                  'source_files':[dict(f,writable=False) for f in files.values() if f['path'].endswith('.py')],
                  'plot_data':scoped_plot_data(files,record['chart'])}
            item['_image']=self.cached_image(project,record['chart'],files['charts/'+record['chart']+'.py']['content'],revision)
            if self.snapshot(project,record['chart'])[1]!=revision:raise ValueError('参照图在读取时发生变化，请重试')
            result.append(item)
        return result

    def context(self, session, record, turn, parent, exception):
        chart_id=record['chart_id']
        files=copy.deepcopy(session['base_sources'][chart_id])
        if parent:
            for path,source in parent['code'].items():
                files[path]['content']=source;files[path]['sha256']=digest(source)
        plot_data=scoped_plot_data(files,record['chart'])
        lineage=[];ancestor=parent
        by_id={d['id']:d for d in session['drafts']}
        while ancestor and ancestor['id'] not in lineage:
            lineage.append(ancestor['id']);ancestor=by_id.get(ancestor.get('parent_draft_id'))
        recent=[]
        for previous in session['turns'][-12:]:
            for result in previous.get('results',[]):
                if result.get('chart_id')==chart_id:
                    recent.append({'turn_id':previous['id'],'user_message':previous['user_message'],
                                   'status':result['status'],'summary':result.get('summary'),
                                   'reason':result.get('reason'),'message':result.get('message'),'draft_id':result.get('draft_id'),
                                   'in_active_lineage':result.get('draft_id') in lineage})
        refs=json.loads(json.dumps(session['references']))
        image_paths=[]
        for ref in refs:
            image_path=ref.pop('_image',None)
            if image_path:image_paths.append((ref['chart_id'],image_path))
        target_image=parent.get('image_path') if parent else record.get('_image')
        if target_image:image_paths.insert(0,('current_target',target_image))
        images=[];image_order=[]
        from chat_agent import lightweight_question
        if effective_model_config()['vision_enabled'] and not lightweight_question(turn['user_message']):
            for ident,path in image_paths[:3]:
                raw=Path(path).read_bytes()
                data=(chat_image_thumbnail(raw) if len(raw)<=4_000_000
                      else chat_image_thumbnail.__wrapped__(raw))
                if len(data)<2_000_000:
                    images.append('data:image/png;base64,'+base64.b64encode(data).decode());image_order.append(ident)
        font_audit=parent.get('font_audit') if parent else None
        if turn['operation']!='normalize' and not font_audit:
            cache_key=parent['id'] if parent else session['base_revisions'][chart_id]
            cache=session.setdefault('font_context_cache',{})
            font_audit=cache.get(cache_key)
            if (font_audit is None
                    and re.search(r'字体|字形|字号|font|typeface|typograph', turn['user_message'], re.I)
                    and not re.search(r'不要修改|不要改|不必修改|无需修改|do not (?:edit|change)|don.t (?:edit|change)', turn['user_message'], re.I)
                    and re.search(r'改|调整|设置|加粗|变细|change|set\b|increase|decrease|resize', turn['user_message'], re.I)):
                from chat_runner import inspect_chart_fonts
                font_audit=inspect_chart_fonts(self.host.project_path(session['project']),
                                               'charts/'+record['chart']+'.py',parent['code'] if parent else None)
                cache[cache_key]=font_audit
                self.save(session)
            if font_audit is None:
                # Non-font edits must not render the entire applied figure just
                # to prepare an LLM request. Both baseline and candidate font
                # audits still run in render_candidate before a preview passes.
                font_audit={'status':'deferred_to_candidate_validation',
                            'reason':'No font preflight required for this request; do not infer resolved fonts.'}
        platform_helper=None
        entry_source=files['charts/'+record['chart']+'.py']['content']
        if turn['operation']=='chat_edit' and 'finish_normalized_figure' in entry_source:
            helper=(self.host.ROOT/'studio_style.py').read_text(encoding='utf-8')
            excerpt=helper[helper.index('def normalize_figure_geometry('):helper.index('def plotting_error_values(')]
            profile=read_json(self.host.NORMALIZATION_PROFILE)
            platform_helper={'path':'@platform/studio_style.py','read_only':True,
                             'content':excerpt,'profile_png_dpi':profile['global']['png_dpi']}
        from panel_index import build_from_sources, validate_mapping, effective_sources
        panel_index = build_from_sources(effective_sources({path: value['content'] for path, value in files.items() if path.endswith('.py')}), record['chart'])
        manual = files.get('panel-mappings/'+record['chart']+'.json')
        if manual:
            mapping = validate_mapping(json.loads(manual['content']))
            panel_index['panels'] = [{'id': key, 'axis_labels': labels, 'status': 'manual', 'source_sections': []} for key, labels in mapping.items()]
            panel_index['warning'] = ''
        selected_id = turn.get('target_panels', {}).get(record['chart'])
        selected_panel = next((p for p in panel_index['panels'] if p['id'] == selected_id), None)
        if selected_id and not selected_panel:
            raise ValueError('所选子图的映射已失效，请重新选择子图')
        data_reference_roots=[]
        native_registry=files.get('native-project.json')
        if native_registry:
            from native_project import selection
            native_id=selection(self.host.project_path(session['project']),'charts/'+record['chart']+'.py',
                                {'charts/'+record['chart']+'.py':entry_source})
            data_reference_roots.extend(['data/native/'+native_id,'data/native/'+native_id+'/data'])
        registry=files.get('universal-project.json')
        if registry:
            descriptor=json.loads(registry['content'])
            if descriptor.get('schema')=='plot-forge-universal/1':
                data_reference_roots.append(descriptor['source_root'])
        from automatic_context import input_mappings
        return {'request_id':uid('req'),'edit_session_id':session['id'],'turn_id':turn['id'],
                'project_id':session['project_id'],'chart_id':chart_id,'target_display_name':record['display_name'],
                'base_revision':session['base_revisions'][chart_id],'parent_draft_id':parent['id'] if parent else None,
                'batch_target_count':len(session['chart_ids']),
                'user_message':turn['user_message'],'source_files':[f for f in files.values() if f['path'].endswith('.py')],
                'plot_data':plot_data,'data_reference_roots':data_reference_roots,
                'input_mappings':input_mappings(files),
                'allowed_write_paths':['charts/'+record['chart']+'.py'],
                'panel_index':panel_index, 'selected_panel':selected_panel,
                'reference_charts':refs,'project_chart_catalog':self.records(session['project'],list(self.identity(session['project'])['charts'])),
                'conversation_context':{'recent_turns':recent,'active_parent_lineage':lineage,
                    'active_source_authoritative':True,'non_lineage_turns':'Historical context only; do not reapply their changes or preservation constraints to this branch.',
                    'active_draft_summary':parent.get('summary') if parent else None},
                'current_font_audit':font_audit,
                'harness_layout_feedback':({'candidate_code':parent['code'],'layout':parent['layout'],
                    'reason':parent.get('reason'),'accepted_exception':exception}
                    if parent and parent.get('review_blocker')=='layout_conflict' else None),
                'platform_render_helper':platform_helper,
                'constraints':['CSV and shared dependencies are read-only','Preserve data and scientific meaning','Only selected chart entry is writable','Default avoid unintended overlap; report unsupported checks'],
                '_layout_reference':parent.get('_layout_reference') if parent and parent.get('review_blocker')=='layout_changed' else None,
                'layout_exception':exception,'visual_context_available':bool(images),'target_image_available':'current_target' in image_order,
                'image_order':image_order,'_images':images}

    def resolve_parent(self,session,chart_id,parents):
        ident=parents.get(chart_id,session['active_drafts'].get(chart_id))
        if ident is None:return None
        candidate=next((d for d in session['drafts'] if d['id']==ident and d['chart_id']==chart_id),None)
        if not candidate or not self.can_continue_draft(candidate):
            raise ValueError('该候选不可继续修改，请选择已生成图片和代码的版本')
        return candidate

    @staticmethod
    def can_continue_draft(draft):
        if not draft.get('image_path') or not draft.get('code'):
            return False
        return draft.get('status') not in ('rendering','discarded')

    @staticmethod
    def can_apply_draft(draft):
        return (ChatHarness.can_continue_draft(draft) and draft.get('status')!='applied'
                and draft.get('review_blocker')!='layout_changed')

    @staticmethod
    def candidate_warnings(draft):
        warnings=list(draft.get('warnings') or [])
        if draft.get('reason'): warnings.append(draft['reason'])
        for key in ('source_data_report','chart_transform'):
            report=draft.get(key) or {}
            if report.get('status') not in (None,'pass','unchanged'):
                warnings.append(report.get('reason') or '原始数据来源或图型转换未能验证。')
        data=draft.get('data_report') or {}
        if data.get('changed') or data.get('removed') or data.get('status') in ('fail','changed','conflict'):
            warnings.append('绘图数据、映射或元素发生变化，请核对原始数值与派生计算。')
        if data.get('added'):
            warnings.append('候选新增了绘图元素，请核对数据来源和图表含义。')
        if data.get('axes_changes') or data.get('visibility_changes'):
            warnings.append('坐标范围或元素可见性发生变化，请核对是否隐藏了数据。')
        for issue in (draft.get('layout') or {}).get('issues',[]):
            warnings.append(issue.get('message') or '检测到布局冲突：'+str(issue.get('kind','未知类型')))
        return list(dict.fromkeys(str(w) for w in warnings if w))

    def exception(self,session,chart_id,body,message):
        requested=body.get('layout_exception')
        if not requested:return session.get('layout_exceptions',{}).get(chart_id)
        quote=requested.get('authorization_quote')
        if not isinstance(quote,str) or not quote or quote not in message:
            raise ValueError('布局例外必须包含本轮用户的明确授权原话')
        ids=requested.get('warning_ids',[])
        diagnostic=next((d for d in reversed(session['drafts']) if d['chart_id']==chart_id and d.get('layout',{}).get('issues')),None)
        known={i['id']:i for i in (diagnostic or {}).get('layout',{}).get('issues',[]) if i.get('id')}
        if not ids or any(i not in known for i in ids):raise ValueError('只能接受已显示的布局冲突')
        result={'chart_id':chart_id,'warning_ids':ids,'issues':[known[i] for i in ids],'authorization_quote':quote,
                'base_revision':session['base_revisions'][chart_id],'diagnostic_draft_id':diagnostic['id'],
                'layout_signature':diagnostic.get('layout_signature')}
        session.setdefault('layout_exceptions',{})[chart_id]=result
        return result

    def turn(self, project, sid, body, normalize=False):
        path=self.path(project,sid)
        guard=lock(path)
        if not guard.acquire(blocking=False):raise ValueError('该会话仍在生成，请等待上一轮结束')
        event=threading.Event()
        with cancellation.GUARD:cancellation.ACTIVE[str(path)]=event
        cancel_context=cancellation.CURRENT.set(event)
        try:
            session=self.load(project,sid)
            if session.get('status')=='closed':raise ValueError('此会话已结束，请新建会话')
            if 'reference_charts' in body:
                requested_refs=body['reference_charts']
                if not isinstance(requested_refs,list) or len(requested_refs)>10:raise ValueError('最多选择 10 张参照图')
                retained={r['chart']:r for r in session['references']}
                fresh={r['chart']:r for r in self.references(project,[r for r in requested_refs if r not in retained])}
                session['references']=[retained.get(r) or fresh[r] for r in dict.fromkeys(requested_refs)]
            message=body.get('user_message','') if not normalize else '按所选 Skill 规范化绘图'
            if not isinstance(message,str) or not message.strip() or len(message)>5000:raise ValueError('请输入不超过 5000 字的修改要求')
            turn={'id':uid('trn'),'user_message':message,'operation':'normalize' if normalize else 'chat_edit','results':[],'created_at':time.time()}
            targets = body.get('target_panels', {}) if not normalize else {}
            if not isinstance(targets, dict) or any(not isinstance(k, str) or not isinstance(v, str) for k,v in targets.items()):
                raise ValueError('子图选择格式无效')
            turn['target_panels'] = targets
            session['turns'].append(turn);session['status']='running';session.pop('completed_at',None);self.save(session)
            records=session['charts']
            override_target=(body.get('layout_exception') or {}).get('chart_id')
            if body.get('layout_exception'):
                if not override_target and len(records)==1:override_target=records[0]['chart_id']
                if override_target not in session['chart_ids']:raise ValueError('请选择已显示冲突的具体目标图')
                records=[r for r in records if r['chart_id']==override_target]
            for record in records:
                cancellation.check()
                result={**record}
                attempt_budget={'used':0}
                session['progress']={'stage':'preparing','chart_id':record['chart_id'],
                                     'display_name':record['display_name'],'started_at':time.time()}
                self.save(session)
                try:
                    self.ensure_current_base(session,record)
                    # Normalization always starts from the applied chart. A
                    # preview left active after the user declines it must not
                    # silently become the input to another standardization.
                    parent=None if normalize else self.resolve_parent(session,record['chart_id'],body.get('parent_drafts',{}))
                    exception=self.exception(session,record['chart_id'],body,message)
                    context=self.context(session,record,turn,parent,exception)
                    cancellation.check()
                    context['_model_attempt_budget']=attempt_budget
                    def context_progress(info):
                        session['progress']={'stage':'reading_context','chart_id':record['chart_id'],
                            'started_at':session.get('progress',{}).get('started_at',time.time()),
                            'display_name':record['display_name'],**info}
                        self.save(session)
                    if not normalize:context['_context_progress']=context_progress
                    context['layout_exception_requested']=bool(body.get('layout_exception'))
                    if exception:
                        diagnostic=next((d for d in reversed(session['drafts']) if d['chart_id']==record['chart_id'] and d.get('layout',{}).get('issues')),None)
                        if diagnostic:
                            context['harness_layout_feedback']={'layout':diagnostic['layout'],'candidate_code':diagnostic['code'],'accepted_exception':exception}
                    if normalize:
                        session['progress']['stage']='model_request';self.save(session)
                        response=cancellation.call(self.normalization,context,body.get('skill_id','chart-normalization'),project,
                                                    use_cache=not body.get('force_refresh',False))
                    else:
                        session['progress']['stage']='model_request';self.save(session)
                        from chart_transform import simple_distribution_request
                        requested_kind=simple_distribution_request(message)
                        verified=(parent or {}).get('chart_transform') or {}
                        if (requested_kind and parent and parent.get('status')=='preview_ready'
                                and verified.get('status')=='pass' and verified.get('kind')==requested_kind):
                            name='箱线图' if requested_kind=='boxplot' else '小提琴图'
                            response={'status':'already_compliant','existing_draft_id':parent['id'],
                                      'reason':f'当前候选已经是{name}，且原始样本检查通过；可直接应用此版，或继续提出具体修改。',
                                      'warnings':[]}
                        else:
                            response=validate_response(context,cancellation.call(self.agent,context))
                        if response['status']=='needs_context':
                            # A uniquely identified reference can be loaded without changing the target.
                            wanted=json.dumps(response,ensure_ascii=False)
                            matches=[c['chart'] for c in context['project_chart_catalog'] if c['chart_id'] in wanted and c['chart_id']!=record['chart_id']]
                            existing={r['chart'] for r in session['references']}
                            if matches and set(matches)-existing:
                                session['references']+=self.references(project,[c for c in matches if c not in existing])
                                context=self.context(session,record,turn,parent,exception)
                                context['_model_attempt_budget']=attempt_budget
                                response=validate_response(context,cancellation.call(self.agent,context))
                        if response['status']=='already_compliant' and self.axis_requirement(message):
                            # Render the unchanged parent through the same Harness checks.
                            # An Agent assertion alone must not establish that ticks and
                            # the drawn spine actually match the requested endpoints.
                            entry=context['allowed_write_paths'][0]
                            source=next(f for f in context['source_files'] if f['path']==entry)
                            response={**response,'status':'candidate',
                                      'proposed_files':[{'path':entry,'base_sha256':source['sha256'],'content':source['content']}],
                                      'summary':response.get('reason') or '检查当前图的坐标轴',
                                      'warnings':response.get('warnings') or [],
                                      'layout_policy':{'mode':'avoid_overlap'},
                                      'expected_effects':['Check requested X/Y axis limits and continuous spine on exported image']}
                    cancellation.check()
                    if response['status']!='candidate':
                        result.update({k:response.get(k) for k in ('status','reason','question','summary','warnings','message')})
                        if response.get('existing_draft_id'):result['draft_id']=response['existing_draft_id']
                    else:
                        session['progress']['stage']='rendering';self.save(session)
                        draft=self.build_draft(session,record,turn,parent,context,response)
                        # Format correction and render repair share three model calls.
                        for repair_attempt in range(MAX_MODEL_ATTEMPTS-1):
                            if (normalize or attempt_budget['used']>=model_attempt_limit(attempt_budget) or exception or
                                    (draft['status'] not in ('render_failed','needs_clarification','no_visible_change','axis_unmet','font_unverified')
                                     and draft.get('review_blocker') not in ('transform_unverified','layout_changed'))):
                                break
                            session['progress']['stage']='repairing';self.save(session)
                            context['request_id']=uid('req')
                            context['harness_layout_feedback']={'candidate_code':draft['code'],'layout':draft.get('layout'),
                                                                 'visual_change':draft.get('visual_change'),
                                                                 'font_audit':draft.get('font_audit'),
                                                                 'chart_transform':draft.get('chart_transform'),
                                                                 'layout_preservation':draft.get('layout_preservation'),
                                                                 'reason':draft.get('reason'),
                                                                 'repair_attempts_remaining':model_attempt_limit(attempt_budget)-attempt_budget['used']}
                            try:
                                repaired=validate_response(context,cancellation.call(self.agent,context))
                                if repaired['status']=='candidate':
                                    draft=self.build_draft(session,record,turn,parent,context,repaired)
                                else:
                                    draft['repair_result']={k:repaired.get(k) for k in ('status','reason','question')}
                                    draft['reason']=draft.get('reason') or repaired.get('reason')
                                    break
                            except Exception as error:
                                draft['warnings'].append('自动修复未完成：'+str(error))
                                break
                        _,after_revision=self.snapshot(project,record['chart'])
                        if after_revision!=context['base_revision']:
                            draft.update(status='revision_conflict',reason='生成期间正式版本或依赖已变化，请新建会话')
                        if normalize and draft['status']=='preview_ready' and not response.get('reused_cache'):
                            try:self.save_normalization_cache(project,context,response)
                            except OSError as error:print(f'Normalization cache unavailable: {error}',flush=True)
                        cancellation.check()
                        session['drafts'].append(draft)
                        if self.can_continue_draft(draft):
                            session['active_drafts'][record['chart_id']]=draft['id']
                        result.update(status=draft['status'],draft_id=draft['id'],summary=draft['summary'],reason=draft.get('reason'),warnings=draft.get('warnings',[]))
                except Exception as error:
                    result.update(status='revision_conflict' if 'revision_conflict' in str(error) else 'cannot_complete',reason=str(error))
                    if getattr(error,'failure_code',None):result['failure_code']=error.failure_code
                cancellation.check()
                if attempt_budget.get('validation_diagnostics'):
                    turn.setdefault('_diagnostics',{})[record['chart_id']]=attempt_budget['validation_diagnostics']
                result['model_attempts']=attempt_budget['used']
                if 'model_seconds' in attempt_budget: result['model_seconds']=round(attempt_budget['model_seconds'],3)
                turn['results'].append(result);session.pop('progress',None);self.save(session)
            session['status']='open';session['completed_at']=time.time();session.pop('progress',None);self.save(session)
            return self.public(session)
        except cancellation.Cancelled:
            if 'turn' in locals():
                turn['results'].append({'chart_id':record['chart_id'] if 'record' in locals() else None,
                                       'status':'cancelled','reason':'已停止本轮改图；正式图表未改变。'})
                session['status']='open';session['completed_at']=time.time();session.pop('progress',None);self.save(session)
                return self.public(session)
            raise ValueError('已停止本轮改图')
        except Exception:
            if 'turn' in locals():
                session['status']='open';session['completed_at']=time.time();session.pop('progress',None);self.save(session)
            raise
        finally:
            cancellation.CURRENT.reset(cancel_context)
            with cancellation.GUARD:cancellation.ACTIVE.pop(str(path),None)
            guard.release()

    def stop(self, project, sid):
        path=self.path(project,sid)
        self.load(project,sid)  # Validate the exact project/session before signalling.
        with cancellation.GUARD:
            event=cancellation.ACTIVE.get(str(path))
            if event is not None:event.set()
        return {'stopping':event is not None,
                'message':'正在停止当前改图；已发出的云端请求可能仍计费。' if event is not None else '当前没有运行中的改图任务。'}

    def normalization_cache_path(self,project,context,skill_id,skill_hash,profile_hash,model_name):
        identity=[context['chart_id'],context['base_revision'],skill_id,skill_hash,profile_hash,model_name]
        name=digest(json.dumps(identity,ensure_ascii=False,sort_keys=True)).split(':',1)[1]
        return self.directory(project)/'normalization_cache'/(name+'.json')

    def save_normalization_cache(self,project,context,response):
        interpreted=response.get('interpreted_request') or {}
        model_name=effective_model_config()['model']
        path=self.normalization_cache_path(project,context,interpreted['skill_id'],interpreted['skill_sha256'],
                                           interpreted['profile_sha256'],model_name)
        atomic_json(path,{'response':response,'source_sha256':next(f['sha256'] for f in context['source_files']
                                                                  if f['path']==context['allowed_write_paths'][0])})

    def normalization(self,context,skill_id,project,use_cache=True):
        from normalizer_agent import normalize_source
        skill,profile=self.host.skill_files(skill_id)
        entry=context['allowed_write_paths'][0]
        source=next(f for f in context['source_files'] if f['path']==entry)
        related={f['path']:f['content'] for f in context['source_files'] if f['path']!=entry}
        url=os.environ.get('NORMALIZER_AGENT_URL')
        model_auth=effective_model_config()
        skill_hash=digest(skill);profile_hash=digest(json.dumps(profile,sort_keys=True))
        if model_auth.get('provider') == 'chatgpt':
            url = None
        cache_path=self.normalization_cache_path(project,context,skill_id,skill_hash,profile_hash,model_auth['model'])
        if use_cache and cache_path.is_file():
            try:cached=read_json(cache_path)
            except (OSError,ValueError) as error:
                print(f'Normalization cache ignored: {error}',flush=True)
                cached={}
            if cached.get('source_sha256')==source['sha256']:
                response=cached.get('response') or {}
                files=response.get('proposed_files') or []
                if (len(files)==1 and files[0].get('path')==entry and files[0].get('base_sha256')==source['sha256']
                        and response.get('status')=='candidate'):
                    print(f"Normalization cache hit: chart_id={context['chart_id']}",flush=True)
                    return {**response,**{k:context[k] for k in ('request_id','edit_session_id','turn_id','parent_draft_id',
                                                                  'chart_id','base_revision','user_message')},
                            'reused_cache':True}
        if url:
            result=post_json(url.rstrip('/')+'/v1/normalize', {'source':source['content'],'data_schema':context['plot_data'],
                           'style_profile':profile,'related_sources':related,'skill_text':skill,
                           'request_id':context['request_id'],'base_revision':context['base_revision'],
                           'model_auth':model_auth}, timeout=150)
            if result.get('request_id')!=context['request_id'] or result.get('base_revision')!=context['base_revision']:
                raise ValueError('规范化 Agent 返回的请求或版本标识不匹配')
        else:
            result=normalize_source(source['content'],context['plot_data'],profile,related,skill,model_auth=model_auth)
        if result['status']!='proposed':
            return {'status':('already_compliant' if result['status']=='already_compliant' else 'cannot_complete' if result['status']=='unsupported' else 'needs_clarification'),
                    'reason':result['message'],'warnings':result.get('warnings',[])}
        return {**{k:context[k] for k in ('request_id','edit_session_id','turn_id','parent_draft_id','chart_id','base_revision','user_message')},
                'status':'candidate','proposed_files':[{'path':entry,'base_sha256':source['sha256'],'content':result['normalized_source']}],
                'summary':result['message'],'warnings':result.get('warnings',[]),'normalization_checks':result.get('check'),
                'unsupported':result.get('unsupported',[]),'interpreted_request':{'operation':'normalize','skill_id':skill_id,
                    'skill_sha256':skill_hash,'profile_version':profile.get('version'),'profile_sha256':profile_hash,
                    'changes':result.get('changes',[])},
                'layout_policy':{'mode':'avoid_overlap'},'expected_effects':result.get('changes',[])}

    def build_draft(self,session,record,turn,parent,context,response):
        if self.renderer is None:
            from chat_runner import render_candidate
        did=uid('dft');output=self.path(session['project'],session['id']).parent/'drafts'/did
        output.mkdir(parents=True)
        code={f['path']:f['content'] for f in response['proposed_files']}
        baseline={f['path']:f['content'] for f in context['source_files'] if f['writable']}
        from chart_transform import requested_distribution, requested_scatter, requested_line
        message = context.get('user_message', '')
        if requested_distribution(message) or requested_scatter(message) or requested_line(message):
            from interactive_style import prepare_conversion_source
            labels = (context.get('selected_panel') or {}).get('axis_labels')
            # Explicit numeric range requests retain the model's requested limits.
            import re
            explicit_range = bool(re.search(r'(?:范围|上限|下限|lim|range).{0,24}[-+]?\d', message, re.I))
            if not explicit_range:
                for path in code:
                    code[path] = prepare_conversion_source(code[path], baseline.get(path, ''), labels, requested_distribution(message))
                response = {**response, 'proposed_files': [
                    {**item, 'content': code[item['path']]} for item in response['proposed_files']]}
        draft={**record,'id':did,'turn_id':turn['id'],'base_revision':context['base_revision'],
               'selected_panel':context.get('selected_panel'),
               'parent_draft_id':context['parent_draft_id'],'code':code,'summary':response.get('summary') or '候选修改',
               'warnings':response.get('warnings',[]),'proposal':response,'created_at':time.time(),'status':'rendering'}
        if context.get('_layout_reference'):draft['_layout_reference']=context['_layout_reference']
        atomic_json(output/'proposal.json',response)
        try:
            render=self.renderer or render_candidate
            render_started=time.monotonic()
            report=render(self.host.project_path(session['project']),context['allowed_write_paths'][0],code,output,baseline_files=baseline)
            report['validation_seconds']=round(time.monotonic()-render_started,3)
            draft.update({k:v for k,v in report.items() if k not in ('status',)})
            draft['warnings']=[*response.get('warnings',[]),*report.get('warnings',[])]
            if context.get('selected_panel'):
                from panel_index import check_panel_scope
                scope = check_panel_scope(report, context['selected_panel'])
                draft['panel_scope_check'] = scope
                if scope.get('warning'):
                    draft['warnings'].append(scope['warning'])
            draft['image_url']=f"/api/projects/{session['project']}/chat/sessions/{session['id']}/drafts/{did}/image"
            issues=report.get('layout',{}).get('issues',[])
            from layout_preservation import check_layout,unchanged_spacing_issues
            normalizing=response.get('interpreted_request',{}).get('operation')=='normalize'
            layout_check=check_layout(context,report,normalizing)
            draft['layout_preservation']=layout_check
            inherited=[] if normalizing else unchanged_spacing_issues(context,report)
            active_issues=[i for i in issues if i not in inherited]
            accepted=context.get('layout_exception') or {}
            if not accepted.get('layout_signature') or accepted.get('layout_signature')!=report.get('layout_signature') or accepted.get('base_revision')!=context['base_revision']:
                if accepted:draft['warnings'].append('布局或正式版本已变化；原有重叠例外不适用于本候选，请重新审阅。')
                accepted={}
            accepted_signatures={(i.get('kind'),json.dumps(i.get('elements'),sort_keys=True)) for i in accepted.get('issues',[])}
            remaining=[i for i in active_issues if (i.get('kind'),json.dumps(i.get('elements'),sort_keys=True)) not in accepted_signatures]
            for i in issues:i.setdefault('id',uid('warn'))
            data_report=report.get('data_report',{})
            source_report=report.get('source_data_report') or {}
            derived_allowed=(source_report.get('status')=='pass' and
                             response.get('interpreted_request',{}).get('operation')!='normalize')
            if derived_allowed:
                draft['source_data_policy']='derived_and_mapping'
            from chart_transform import verify_distribution, verify_scatter, verify_line
            transform=None if derived_allowed else verify_scatter(context, report)
            if transform is None and not derived_allowed:
                transform=verify_line(context, report)
            if transform is None and not derived_allowed:
                transform=verify_distribution(self.host.project_path(session['project']),record['chart'],context,response,report)
            if transform:
                draft['chart_transform']=transform
                draft['warnings'].extend(transform.get('warnings',[]))
            transformed=derived_allowed or bool(transform and transform['status']=='pass')
            font_issue=self.font_effect_issue(report)
            visual_issue=None if response.get('interpreted_request',{}).get('operation')=='normalize' else self.visual_effect_issue(context,response,report)
            # Accepting the displayed layout intentionally keeps the same pixels.
            # A carried-over exception must not waive later visual edit requests.
            if (context.get('layout_exception_requested') and accepted and issues and not remaining
                    and report.get('visual_change',{}).get('status')=='identical'):
                visual_issue=None
            axis_issue=self.axis_requirement_issue(context,report) if response.get('interpreted_request',{}).get('operation')!='normalize' else None
            if source_report.get('status')=='fail':
                draft.update(status='validation_failed',reason=source_report['reason'])
            elif response.get('normalization_checks',{}).get('status')=='fail':
                draft.update(status='needs_clarification',reason='候选已出图，但尚未满足所选规范的结构检查；请查看检查结果。')
            elif layout_check['status']=='fail':
                draft.update(status='validation_failed',review_blocker='layout_changed',reason=layout_check['reason'])
                from layout_preservation import reference
                draft['_layout_reference']=reference(context,report)
            elif transform and transform['status']!='pass':
                draft.update(status='validation_failed',reason=transform['reason'])
                if transform['status']=='unverified':draft['review_blocker']='transform_unverified'
            elif (data_report.get('status') in ('fail','changed','conflict') or
                  (not transformed and (data_report.get('changed') or data_report.get('removed')))):
                draft.update(status='validation_failed',reason='绘图结果发生变化，但尚未确认原始数据保持不变；请保留原始输入并单独计算派生值，再重新检查候选。')
            elif not transformed and (data_report.get('visibility_changes') or data_report.get('axes_changes')) and not self.view_change_authorized(response, context):
                draft.update(status='needs_clarification',reason='可见范围或元素可见性发生了变化，但原话中尚无对应的明确修改项；请确认修改意图。')
            elif not transformed and data_report.get('added') and not self.addition_authorized(response,context,data_report['added']):
                draft.update(status='needs_clarification',reason='候选新增了绘图元素，但没有与原话对应的明确新增要求；请确认新增元素及数据来源。')
            elif font_issue:
                draft.update(status='font_unverified',reason=font_issue)
            elif remaining and report.get('layout',{}).get('status')=='conflict':
                draft.update(status='needs_clarification',review_blocker='layout_conflict',
                    reason='候选存在布局冲突；可以直接继续对话，基于此版修复布局，通过检查后才能应用。也可在审阅后明确接受所列冲突。')
            elif axis_issue:
                draft.update(status='axis_unmet',reason=axis_issue)
            elif visual_issue and report.get('visual_change',{}).get('status')=='identical' and self.axis_requirement(context.get('user_message','')):
                draft.update(status='already_compliant',reason='当前版导出图的坐标范围、所要求的端点刻度和连续轴线已符合本轮要求；图片未变化，无需应用新版本。')
            elif visual_issue:
                draft.update(status='no_visible_change',reason=visual_issue)
            else:
                draft['status']='preview_ready'
                if derived_allowed and any(data_report.get(key) for key in ('changed','removed','added')):
                    draft['warnings'].append('原始输入检查通过；本候选包含派生计算或绘图映射变化，请审阅计算方法与图表含义。')
                if data_report.get('added') and not transformed:
                    draft['warnings'].append('新增绘图元素的数据含义需人工审阅；现有绘图数值检查保持不变。')
                if data_report.get('visibility_changes') or data_report.get('axes_changes'):
                    draft['warnings'].append('可见范围或元素可见性发生变化，请对照本轮要求审阅。')
                if inherited and not active_issues:
                    draft['layout']['status']='preserved_existing'
                    draft['warnings'].append('已保留原有排版；原图已有的间距提示没有触发自动重排。')
                elif issues and not remaining:
                    draft['layout']['status']='accepted_exception';draft['warnings'].append('已按你的明确要求保留所列布局冲突。')
                elif report.get('layout',{}).get('status')=='unverified':
                    draft['warnings'].append('部分布局无法自动确认，请审阅候选图片；此结果不表示完全无重叠。')
            draft['warnings'].extend(issue for issue in (font_issue,axis_issue,visual_issue) if issue)
            draft['warnings']=self.candidate_warnings(draft)
            if report.get('naming',{}).get('display_name'):draft['display_name']=report['naming']['display_name']
        except Exception as error:
            draft.update(status='render_failed',reason=str(error))
        return draft

    def font_effect_issue(self,report):
        audit=report.get('font_audit') or {}
        if audit.get('missing_glyphs'):
            sample=audit['missing_glyphs'][0]
            return (f"导出图中字体 {sample.get('font','未知')} 缺少字符 {sample.get('characters','')}；"
                    '该候选无法正确显示全部文字，不能标为已达到要求。')
        old={item['key']:item for item in (report.get('baseline_layout_signature') or {}).get('texts',[])}
        new={item['key']:item for item in (report.get('layout_signature') or {}).get('texts',[])}
        baseline_subs={(item.get('text'),item.get('requested_family'))
                       for item in (report.get('baseline_font_audit') or {}).get('substitutions',[])}
        introduced={(item.get('text'),item.get('requested_family'))
                    for item in audit.get('substitutions',[])}-baseline_subs
        if not introduced:
            return None
        for key,item in new.items():
            before=old.get(key)
            if not before or item.get('text')!=before.get('text') or not any(item.get('text')==text for text,_ in introduced):
                continue
            old_box,new_box=before['bbox'],item['bbox']
            for start,end in ((0,2),(1,3)):
                prior=old_box[end]-old_box[start]
                current=new_box[end]-new_box[start]
                if prior>1 and abs(current/prior-1)>.15:
                    return ('原字体缺失后使用 STHeiti，且相同文字在导出图中的尺寸变化超过 15%；'
                            '替代字体引起明显排版变化，请调整布局或字体后再审阅。')
        return None

    def axis_requirement(self,message):
        axis_pattern=re.compile(r'([xy])\s*(?:轴|-axis|\s+axis)|xy\s*轴|x\s*[、,和与及]\s*y\s*轴',re.IGNORECASE)
        range_pattern=re.compile(r'(?<![\d.])(-?\d+(?:\.\d+)?)\s*(?:～|~|至|到|—|–)\s*(-?\d+(?:\.\d+)?)(?![\d.])')
        mentions=list(axis_pattern.finditer(message))
        ranges=list(range_pattern.finditer(message))
        if not mentions or not ranges:return None
        requirements=[]
        for index,mention in enumerate(mentions):
            end=mentions[index+1].start() if index+1<len(mentions) else len(message)
            clause=message[mention.start():end]
            match=next((item for item in ranges if mention.end()<=item.start()<end),None)
            if match is None and len(ranges)==1:
                match=ranges[0]
            if match is None:continue
            lower,upper=map(float,match.groups())
            if lower>=upper:continue
            names=[mention.group(1).lower()] if mention.group(1) else ['x','y']
            for name in names:
                requirements.append({'axis':name,'lower':lower,'upper':upper,
                                     'ticks':'刻度' in clause or 'tick' in clause.lower()})
        return requirements or None

    def axis_requirement_issue(self,context,report):
        requirement=self.axis_requirement(context.get('user_message',''))
        if not requirement:return None
        axes=report.get('axis_details') or []
        if len(axes)!=1:
            return '本轮要求涉及坐标轴范围，但导出图含多个坐标轴，无法自动确认目标轴；请指定是哪一幅子图。'
        axis=axes[0]
        for item in requirement:
            name=item['axis'];lower=item['lower'];upper=item['upper']
            label=name.upper();spine='bottom' if name=='x' else 'left'
            tolerance=max(abs(upper-lower)*1e-6,1e-8)
            near=lambda a,b:abs(a-b)<=tolerance
            limits=axis.get(name+'lim') or []
            if len(limits)!=2 or not all(near(a,b) for a,b in zip(limits,(lower,upper))):
                return f'导出图的 {label} 轴范围不是 {lower:g}～{upper:g}；请设置两端显示边界。'
            if item['ticks']:
                ticks=axis.get('major_'+name+'ticks') or []
                if not any(near(t,lower) for t in ticks) or not any(near(t,upper) for t in ticks):
                    return f'导出图的 {label} 轴刻度未同时显示 {lower:g} 和 {upper:g}；请明确设置端点刻度。'
            bounds=axis.get(spine+'_spine_bounds') or []
            if not axis.get(spine+'_spine_visible') or len(bounds)!=2 or not all(near(a,b) for a,b in zip(bounds,(lower,upper))):
                return f'导出图的 {label} 轴线未从 {lower:g} 连续延伸到 {upper:g}；请调整轴线端点。'
            if not axis.get(spine+'_spine_continuous'):
                return f'导出图的 {label} 轴线不是连接 {lower:g}～{upper:g} 的同一条连续线；请修复断线或分段绘制。'
        return None

    def visual_effect_issue(self,context,response,report):
        visual=report.get('visual_change') or {}
        if visual.get('status')=='identical':
            return '候选图片与上一版逐像素相同；请检查请求是否已由上一版满足，或调整未生效的绘图参数。'
        message=context.get('user_message','')
        operation_text=' '.join(str(op.get('target_element',''))+' '+str(op.get('property',''))
                                for op in response.get('interpreted_request',{}).get('operations',[]) if isinstance(op,dict)).lower()
        if not (('y-axis label' in operation_text or 'y轴' in operation_text.lower())
                and ('weight' in operation_text or '粗度' in message or '字重' in message)):
            return None
        fraction=re.search(r'(?<!\d)(\d+)\s*/\s*(\d+)(?!\d)',message)
        if not fraction:return None
        denominator=int(fraction.group(2))
        if not denominator:return None
        expected=int(fraction.group(1))/denominator
        if not 0.1 <= expected < 1:return None
        ratios=visual.get('text_ink_ratios') or {}
        ylabel_ratios=[value for key,value in ratios.items() if key.endswith('.ylabel')]
        if len(ylabel_ratios)==1 and abs(ylabel_ratios[0]-expected)>0.1:
            actual=ylabel_ratios[0]
            return (f'候选图的 Y 轴标题墨色约为上一版的 {actual:.0%}，与要求的 {expected:.0%} 相差较大。'
                    '字体字重数值不等于实际笔画粗细；请调整可用字形或描边后重新出图。')
        return None

    def addition_authorized(self,response,context,added):
        if response.get('interpreted_request',{}).get('operation')=='normalize':
            return bool(context.get('plot_data')) and all(item.get('semantic_role') in ('errorbar','violin_quartiles') for item in added)
        for op in response.get('interpreted_request',{}).get('operations',[]):
            prop=str(op.get('property','')).lower()
            requested=('add','新增','添加','补','errorbar','error_bar','error bar','误差','quartile','分位','annotation','标注')
            if any(term in prop for term in requested) and any(q and q in context['user_message'] for q in op.get('source_quotes',[])):
                return True
        return False

    def view_change_authorized(self,response,context):
        # Explicit requested presentation changes can be reviewed; generic styling cannot hide data.
        if response.get('interpreted_request',{}).get('operation')=='normalize':
            return False
        properties=('xlim','ylim','axis range','axis_range','visible','visibility','alpha','opacity','scale','坐标范围','可见','隐藏','透明度')
        for op in response.get('interpreted_request',{}).get('operations',[]):
            prop=str(op.get('property','')).lower()
            if any(value in prop for value in properties) and any(q and q in context['user_message'] for q in op.get('source_quotes',[])):
                return True
        return False

    def draft_action(self,project,sid,did,action):
        path=self.path(project,sid)
        with lock(path),lock(self.host.project_path(project)):
            session=self.load(project,sid)
            if session.get('status')=='closed':raise ValueError('此会话已结束，请新建会话')
            if session.get('status')=='running':raise ValueError('请等待本轮生成结束')
            draft=next((d for d in session['drafts'] if d['id']==did),None)
            if not draft:raise ValueError('候选不存在')
            if action=='recheck':
                if draft['status'] in ('applied','discarded') or not draft.get('proposal'):
                    raise ValueError('请选择尚未应用的候选重新检查')
                record=next(r for r in session['charts'] if r['chart_id']==draft['chart_id'])
                self.ensure_current_base(session,record)
                origin=next(t for t in session['turns'] if t['id']==draft['turn_id'])
                parent=next((d for d in session['drafts'] if d['id']==draft.get('parent_draft_id')),None)
                if draft.get('parent_draft_id') and not parent:raise ValueError('原候选的父版本已不存在，请重新生成')
                context=self.context(session,record,origin,parent,session.get('layout_exceptions',{}).get(draft['chart_id']))
                if draft.get('_layout_reference'):context['_layout_reference']=draft['_layout_reference']
                proposal=json.loads(json.dumps(draft['proposal']))
                from chat_agent import ECHO_FIELDS
                for key in ECHO_FIELDS:proposal[key]=context[key]
                current_sources={item['path']:item['sha256'] for item in context['source_files']}
                for item in proposal.get('proposed_files',[]):
                    if item['path'] in current_sources:
                        item['base_sha256']=current_sources[item['path']]
                validate_response(context,proposal)
                checked=self.build_draft(session,record,origin,parent,context,proposal)
                _,revision=self.snapshot(project,record['chart'])
                if revision!=context['base_revision']:
                    checked.update(status='revision_conflict',reason='检查期间正式版本或依赖已变化，请重新生成')
                checked['rechecked_from']=draft['id'];session['drafts'].append(checked)
                if self.can_continue_draft(checked):
                    session['active_drafts'][draft['chart_id']]=checked['id']
            elif action=='discard':
                if draft['status']=='applied':raise ValueError('正式版不能作为候选丢弃')
                draft['status']='discarded'
                if session['active_drafts'].get(draft['chart_id'])==did:session['active_drafts'].pop(draft['chart_id'],None)
            elif action=='activate':
                if not self.can_continue_draft(draft):raise ValueError('该版本不能作为继续修改的起点')
                self.resolve_parent(session,draft['chart_id'],{draft['chart_id']:did})
                session['active_drafts'][draft['chart_id']]=did
            elif action=='apply':
                if draft.get('review_blocker')=='layout_changed':
                    raise ValueError('这版额外改变了原排版，需要先恢复原有大小和位置，再应用。')
                if not self.can_apply_draft(draft):
                    raise ValueError('候选缺少可用图片或代码，无法应用')
                record=next(r for r in session['charts'] if r['chart_id']==draft['chart_id'])
                _,revision=self.snapshot(project,record['chart'])
                if revision!=draft['base_revision']:
                    draft.setdefault('warnings',[]).append('正式版本或依赖已变化；本次按所选候选覆盖当前绘图代码，请核对数据与图片。')
                    record.pop('_image',None)
                draft['warnings']=self.candidate_warnings(draft)
                official_image=record.get('_image')
                if not official_image:
                    baseline_draft=next((d for d in session['drafts'] if d['chart_id']==draft['chart_id'] and d['base_revision']==draft['base_revision'] and d.get('parent_draft_id') is None and d.get('baseline_image_path')),None)
                    official_image=baseline_draft.get('baseline_image_path') if baseline_draft else None
                self.commit_draft(project,draft,official_image)
                draft['status']='applied'
                files,revision=self.snapshot(project,draft['chart'])
                session['base_sources'][draft['chart_id']]=files;session['base_revisions'][draft['chart_id']]=revision
                session['active_drafts'].pop(draft['chart_id'],None)
                for record in session['charts']:
                    if record['chart_id']==draft['chart_id']:
                        record['display_name']=draft['display_name'];record['_image']=draft.get('image_path')
            else:raise ValueError('Unknown draft action')
            self.save(session);return self.public(session)

    def finalize(self,project,chart):
        """Delete one chart's archived code/images only after the UI's finalize action."""
        p,_=self.host.chart_path(project,chart)
        chart_id=self.identity(project)['charts'][chart]
        paths=sorted((self.directory(project)/'sessions').glob('*/session.json'))
        guards=[]
        try:
            # Never clean files while a candidate is being written. Acquire session locks
            # before the project lock, matching draft_action's lock order.
            for path in paths:
                guard=lock(path)
                if not guard.acquire(blocking=False):raise ValueError('项目仍在生成候选，请结束后再清理历史')
                guards.append(guard)
            with lock(p):
                retained_assets=set()
                for path in paths:
                    session=read_json(path)
                    if chart_id in session['chart_ids']:
                        session['status']='closed'
                        session.get('base_sources',{}).pop(chart_id,None)
                        session.get('active_drafts',{}).pop(chart_id,None)
                        session.get('layout_exceptions',{}).pop(chart_id,None)
                        for record in session['charts']:
                            if record['chart_id']==chart_id:
                                record.pop('_image',None);record['finalized']=True
                        session['drafts']=[d for d in session['drafts'] if d['chart_id']!=chart_id]
                        for turn in session['turns']:
                            turn['results']=[r for r in turn.get('results',[]) if r['chart_id']!=chart_id]
                        session['turns']=[t for t in session['turns'] if t['results']]
                    session['references']=[r for r in session['references'] if r['chart_id']!=chart_id]
                    self.save(session)
                    for folder in (path.parent/'drafts').glob('dft_*'):
                        proposal=folder/'proposal.json'
                        if proposal.is_file() and read_json(proposal).get('chart_id')==chart_id:
                            shutil.rmtree(folder)
                    for record in [*session['charts'],*session['references'],*session['drafts']]:
                        if record.get('_image'):retained_assets.add(record['_image'])
                for asset in (self.directory(project)/'reference_assets').glob('*.png'):
                    if str(asset) not in retained_assets:asset.unlink()
                for item in self.host.read_history(p,chart):
                    for suffix in (*self.host.IMAGE_TYPES,'.py'):
                        (p/'history'/(item['id']+suffix)).unlink(missing_ok=True)
                (p/'history'/(chart+'.json')).unlink(missing_ok=True)
                return {'message':'已清理该图的历史代码、历史图片及 Chat 候选，当前代码和图片已保留。相关会话已结束；下一次修改会新建会话。既有 Git 提交不受影响。'}
        finally:
            for guard in reversed(guards):guard.release()

    def commit_draft(self,project,draft,official_image=None):
        from chart_naming import RenderedImage
        p,f=self.host.chart_path(project,draft['chart'])
        chart=draft['chart'];source=draft['code']['charts/'+chart+'.py'];old=f.read_text(encoding='utf-8')
        history=self.host.read_history(p,chart)
        # Snapshot all files this small commit touches so I/O failure can restore the prior state.
        existing_history=[p/'history'/(h['id']+ext) for h in history for ext in (*self.host.IMAGE_TYPES,'.py')]
        touched=[f,p/'history'/(chart+'.json'),*existing_history,*((p/'previews').glob(chart+'.*')),*((p/'chart_metadata').glob(chart+'.*'))]
        if (p/'native-project.json').is_file():touched.extend([p/'.preparation/state.json',p/'validation/native.json'])
        originals={path:path.read_bytes() for path in touched if path.is_file()}
        history_dir=p/'history';history_dir.mkdir(exist_ok=True)
        added_ids=[]
        try:
            now=datetime.now(timezone.utc).isoformat()
            if not history:
                base=uid('rev');added_ids.append(base);(history_dir/(base+'.py')).write_text(old,encoding='utf-8', newline="\n")
                baseline=Path(official_image or '')
                initial_image=baseline.read_bytes() if baseline.is_file() else None
                missing_baseline=initial_image is None and bool(draft.get('baseline_render_error'))
                if not missing_baseline:self.host.snapshot_image(p,chart,base,old,initial_image)
                history.append({'id':base,'time':now,'note':'初始版本未成功出图，仅保留代码' if missing_baseline else '初始版本',
                                'image_unavailable':missing_baseline})
            else:(history_dir/(history[-1]['id']+'.py')).write_text(old,encoding='utf-8', newline="\n")
            revision=uid('rev')
            added_ids.append(revision)
            image=RenderedImage(Path(draft['image_path']).read_bytes());image.naming=draft.get('naming');image.render_report=draft
            temporary=f.with_suffix('.tmp');temporary.write_text(source,encoding='utf-8', newline="\n");temporary.replace(f)
            (history_dir/(revision+'.py')).write_text(source,encoding='utf-8', newline="\n")
            self.host.save_preview(p,chart,source,image)
            self.host.snapshot_image(p,chart,revision,source,image)
            history.append({'id':revision,'time':now,'note':str(draft['summary'])[:300],'draft_id':draft['id'],'author':self.host.SYNC.config().get('name','本地协作者')})
            # Preserve the initial, previous, current and intermediate source
            # snapshots. Only the explicit finalize action clears history.
            self.host.write_history(p,chart,history)
        except Exception:
            patterns=[(history_dir,ident+'.*') for ident in added_ids]+[(history_dir,chart+'.json'),(p/'previews',chart+'.*'),(p/'chart_metadata',chart+'.*')]
            for directory,pattern in patterns:
                for path in directory.glob(pattern):
                    if path.is_file() and path not in originals:path.unlink()
            for path,data in originals.items():path.write_bytes(data)
            raise
