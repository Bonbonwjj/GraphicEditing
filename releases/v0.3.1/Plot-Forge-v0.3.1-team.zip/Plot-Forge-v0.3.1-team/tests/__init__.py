"""GraphicEditing test suite."""
