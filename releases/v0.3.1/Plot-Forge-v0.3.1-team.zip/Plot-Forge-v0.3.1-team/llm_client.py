"""Small OpenAI-compatible Chat Completions client used by all LLM workflows."""
import json
import os
import urllib.error
import urllib.request


from model_config import DEFAULT_URL, DEFAULT_MODEL


def is_configured():
    from model_config import _preferences
    if _preferences().get('provider') == 'chatgpt':
        from chatgpt_auth import public
        return public()['sharing']
    if os.environ.get("LLM_API_URL") or os.environ.get("LLM_API_KEY") or os.environ.get("OPENAI_API_KEY"):
        return True
    from model_config import effective
    return bool(effective()["api_key"])


def _settings():
    from model_config import effective, validate_url
    saved = effective()
    if saved.get('provider') == 'chatgpt':
        return {**saved, 'url': saved['api_url'], 'key': '', 'timeout': 180}
    url = validate_url(os.environ.get("LLM_API_URL") or saved["api_url"])
    return {
        "url": url,
        "key": (os.environ.get("LLM_API_KEY") or os.environ.get("OPENAI_API_KEY") or saved["api_key"]).strip(),
        "model": (os.environ.get("LLM_MODEL") or saved["model"]).strip(),
        "timeout": float(os.environ.get("LLM_TIMEOUT_SECONDS", "60")),
    }


def chat(messages, temperature=0.1):
    if not is_configured():
        from model_config import _preferences
        if _preferences().get('provider') == 'chatgpt':
            raise ValueError('请先在模型配置中登录 ChatGPT 并获得订阅共享授权；Pro 账户是否可用以官方授权结果为准。')
        raise ValueError("Set LLM_API_KEY (or OPENAI_API_KEY), or configure a local LLM_API_URL")
    settings = _settings()
    payload = {"model": settings["model"], "messages": messages, "temperature": temperature}
    headers = {"Content-Type": "application/json"}
    if settings["key"]:
        headers["Authorization"] = "Bearer " + settings["key"]
    request = urllib.request.Request(settings["url"], data=json.dumps(payload).encode("utf-8"),
                                     headers=headers, method="POST")
    try:
        from model_transport import open_completion
        with open_completion(request, timeout=settings["timeout"], settings=settings) as response:
            result = json.load(response)
        content = result["choices"][0]["message"]["content"]
    except (KeyError, IndexError, TypeError, json.JSONDecodeError) as error:
        raise ValueError("LLM response did not match the Chat Completions format") from error
    except (urllib.error.HTTPError, urllib.error.URLError, TimeoutError) as error:
        detail = error.read().decode(errors="replace")[:700] if isinstance(error, urllib.error.HTTPError) else str(error)
        raise ValueError("LLM request failed: " + detail) from error
    if isinstance(content, list):
        content = "".join(part.get("text", "") for part in content if isinstance(part, dict))
    if not isinstance(content, str) or not content.strip():
        raise ValueError("LLM returned empty content")
    return content.strip()
